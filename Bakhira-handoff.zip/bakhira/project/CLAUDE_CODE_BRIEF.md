# BAKHIRA: THE CURSED STREAM — Build Brief for Claude Code

You are building a browser-based, side-scrolling beat-em-up / platformer in the style of **Cactus McCoy** (Flipline Studios, 2011). The game is called **BAKHIRA: THE CURSED STREAM**. A full pitch deck of screens and visuals lives in `Bakhira Game Design.html` in this project — open it and use it as your visual reference at every step.

## High-level concept

A streamer ("BAKHIRA") is streaming with his girlfriend when a hooded figure called **THE DREADMOD** appears out of the chat, kidnaps her, and curses him. He grabs his bat and fights through 6 stages of trolls — culminating in a castle by the coast — to get her back.

Tone: **pulp comic book** — heavy black ink, halftone dots, yellow caption boxes, magenta "curse" SFX bursts, big shouty SFX text ("WHACK!", "CLACK!", "BANG!"). Think comic panels meets 2D platformer.

## Tech stack

- **Engine:** Phaser 3 (latest stable) loaded from CDN.
- **No build step.** Plain `index.html` + ES modules. Must run by opening `index.html` directly.
- **Render:** Canvas 2D (Phaser default). Target resolution 1280×720, letterboxed to viewport.
- **Audio:** Howler.js or Phaser's built-in audio.
- **Storage:** `localStorage` for save state (stage progress, high score, settings).
- **No external dependencies beyond Phaser + Howler.**

## Provided assets (in `assets/`)

- `hero.png` — transparent PNG of the streamer (the player character). Use as a single sprite; flip horizontally for left-facing. No animation frames provided — you'll need to fake walk/swing with small Y-offsets, slight rotation, and a swing-arc sprite overlay.
- `castle-bg.png` — wide gothic castle on a coastal cliff at night. Use as parallax background for the castle stages.

Anything else (icons, weapons, enemies, pickups, particles) you draw with **plain CSS/SVG/canvas primitives** in the comic-pulp style — solid fills, 3–4px black outlines, drop shadows offset 3–4px to the right and down. **Do NOT generate detailed art**; placeholder geometric shapes with thick black outlines are the intended aesthetic.

### Enemy faces — drop-in player photos

Each enemy type has a circular head slot. The slot should accept a user-supplied image URL via a config object. Provide a `enemies.config.json` at project root like:

```json
{
  "stage1": {
    "trolls": ["faces/player1.png", "faces/player2.png", "faces/player3.png"],
    "miniBoss": "faces/miniboss1.png"
  },
  "stage2": { ... }
}
```

If no image is provided for a slot, render a hatched diagonal-stripe placeholder with the text `[FACE]`. The user will drop `.png` files into `faces/` and update the JSON.

## Visual system (match the pitch HTML exactly)

**Palette** (CSS custom properties; mirror in Phaser):
- `--ink: #0a0a12` — outlines, text base
- `--paper: #efe7d3` — UI backgrounds, hero outline
- `--caption: #f5db7a` — caption boxes, highlights
- `--curse: #c44a8c` — magenta curse / villain / hype
- `--blood: #c8323a` — damage, blood, critical
- `--night: #0d1628` — sky, deep shadows
- `--gold: #e8b04a` — pickups, score
- `--cyan: #5fb6c8` — water, electric weapons
- `--green: #5fa05a` — health pickups, cleared state

**Fonts** (Google Fonts, load in `<head>`):
- `Bangers` — display / SFX / shouts
- `Bungee` — stage banners
- `Oswald` (700) — HUD labels, condensed UI
- `Special Elite` — caption boxes, body
- `VT323` — HUD numbers (score, timer)

**Comic effects to implement:**
- **Caption boxes:** yellow `#f5db7a` rectangles with 2–3px black border + 3px black box-shadow offset bottom-right, Special Elite typewriter font.
- **Speech bubbles:** rounded paper-colored boxes with a 45°-rotated square tail, Bangers font inside.
- **SFX bursts:** large Bangers text with `-webkit-text-stroke: 3px var(--ink)`, drop-shadow `4px 4px 0 var(--ink)`, slight random rotation (-10° to +10°). Spawn on every hit, pickup, jump-land, and boss attack.
- **Halftone overlay:** `background-image: radial-gradient(rgba(0,0,0,.25) 1px, transparent 1.5px); background-size: 6px 6px;` on dark areas for that dotted-comic feel.
- **Scanlines:** subtle 1px horizontal scanlines over the entire game canvas.
- **Camera shake:** on heavy hits, boss attacks, pit deaths.

## Game structure

### Screen flow

1. **Title screen** — castle bg + hero + big "BAKHIRA" logo. Menu: START NEW STREAM, CONTINUE, STAGE SELECT, SETTINGS. "PRESS [ENTER] TO BEGIN" blinking footer.
2. **Story intro** — 6 comic panels, fade-in with typewriter caption text, advance with SPACE. Story beats:
   1. Streamer + GF, "WEDNESDAY NIGHT. THE STREAM IS POPPING."
   2. Chat gets weird, `DREAD_M0D` appears.
   3. Hooded figure steps out of monitor — "CLACK!" SFX.
   4. Kidnap — purple swoosh, GF's bubble "BABE—!!"
   5. Curse circle around hero — "ENJOY THE CURSE, STREAMER."
   6. Hero with bat, castle in distance — "I'M COMING FOR HER."
3. **Stage select** — 6 stage tiles in a 3×2 grid: 01 The Stream Room, 02 Darkweb Alley, 03 Coastal Cliffs, 04 Castle Gates, 05 Dungeon Halls, 06 Throne Room (final). Tiles show locked/current/cleared states; clicking a non-locked tile loads that stage.
4. **Gameplay** — see below.
5. **Boss fight** — replaces normal gameplay HUD when the boss spawns at the end of a stage. See "Boss" section.
6. **Stage clear** — "KNOCKOUT!" SFX + score breakdown panel (kills, best combo, sub tokens, HP remaining, total). Buttons: NEXT STAGE, MAP.
7. **Game over** — "STREAM ENDED." with blood-red palette. Retry / Quit.
8. **Victory** (after stage 6) — GF freed, group bow to camera, "STREAM RESUMED ✓".

### Gameplay screen (the main thing)

Side-scrolling, scrolling right (and occasionally up/down). The level has **three vertical tiers**:

- **Low path** — main walkable ground (cobblestone strip).
- **Mid platform** — ruined castle ramparts on the right side; reached via stairs or by jumping.
- **High platform** — small tower top + floating stone slabs as platforms between tiers.

**Obstacles per stage theme** (castle/gothic for stages 3–6):
- Spike traps (stone spikes on ground — instant 1 HP loss + knockback)
- Wooden crates (smash for random pickup — heart, energy drink, sub token, or weapon)
- Wooden barrels (smash; some are explosive — radius damage to enemies)
- Wall torches (decorative, but emit warm light radius)
- Gargoyle statues (decorative; some animate and drop down as enemies after you pass)
- Pit traps (gaps in the ground — falling = death + respawn at last checkpoint)
- Flying bat enemies (ghost bats with glowing magenta eyes; dive at player)

For stages 1–2 (Stream Room / Darkweb Alley), swap castle theme for indoor: couches, monitors, RGB strips, alley dumpsters, neon signs. Use same color palette.

### Player controls

- `←` / `→` — move
- `↑` or `SPACE` — jump (double-tap for double-jump if Hype meter > 50%)
- `↓` — drop through one-way platforms
- `X` — swing held weapon (3-hit combo: light, light, heavy knockback)
- `Y` — Hype Raid (spin attack, consumes 50% of hype meter, AOE damage + invincible frames)
- `B` or `SHIFT` — dodge roll (invincible frames, knocks over small mobs)
- `Z` or `E` — pick up / throw weapon. Hold to charge throw, release to yeet.
- `ESC` — pause menu.

### Combat

- Hero has **5 HP hearts** and **3 lives** per stage.
- Hit = lose 1 heart + knockback + 0.5s invincibility flash.
- 0 HP = lose a life, respawn at last checkpoint.
- 0 lives = Game Over.
- **Combo counter** increments on each enemy hit within 2s of the last hit. Resets if 2s elapse with no hit, or you take damage. Combo multiplies score.
- **Hype meter** (0–100) fills with each enemy hit (+5) and pickup (+10 energy drink). At 50%+, unlocks double-jump; at 100%, unlocks Hype Raid.
- **Knockback:** hit enemies fly back, can knock OTHER enemies down on collision (cascade combos).

### Weapons

Weapons are **picked up off the ground** (not stored in inventory). Holding `Z` near a weapon picks it up; pressing `Z` while holding throws it. Current weapon shows in bottom-left HUD with a durability bar. When durability hits 0, weapon breaks and disappears.

| Weapon | Tag | DMG | SPD | DUR | Rarity | Notes |
|---|---|---|---|---|---|---|
| Fists | melee | 1 | 4 | ∞ | starter | No weapon held |
| Bat | melee | 2 | 3 | 100 | common | The hero's starter bat |
| Keyboard | thrown | 1 | 5 | 1 | common | One-shot ranged |
| Mic Stand | melee, reach | 3 | 2 | 80 | uncommon | Long reach, stun |
| RGB Sword | melee, crit | 4 | 3 | 60 | rare | Cyan glow, crits on every 3rd hit |
| Dono Rocket | ranged, AOE | 5 | 4 | 5 | rare | 5 shots, blast radius |
| Banhammer | heavy, AOE | 5 | 1 | 40 | epic | Slow swing, hits all mobs in range |
| Cursed Key | special | 6 | 2 | 1 | legendary | Only spawns in Stage 6, one-hit on Dreadmod's shield |

Weapons spawn:
- Pre-placed on the level (lying on platforms)
- Dropped by killed enemies (chance based on enemy tier)
- From smashed crates

### Pickups

| Pickup | Effect | Spawn |
|---|---|---|
| Heart | +1 HP | Crates, enemy drops |
| Energy Drink | +25 Hype | Crates, hidden rooms |
| Pizza Slice | +2 HP | Rare drop |
| Sub Token | +1000 score | Enemy drops, gem trails |
| Extra Life | +1 Life | One per stage, hidden |
| Chat Shield | 10s invuln | Boss fights only |

### Enemies

Generic mob types (face slot + body color):

| Type | HP | DMG | Behavior | Color |
|---|---|---|---|---|
| Pleb Troll | 2 | 1 | Walks toward player, swings on contact | `#3a2840` |
| Spam Bot | 1 | 1 | Spawns in waves, fast, low HP | `#2a3a3f` |
| Hater | 3 | 2 | Throws keyboards at player from range | `#3f2a32` |
| Lurker | 4 | 1 | Tanky, blocks; flinch on heavy hits only | `#2a2a35` |
| Ghost Bat | 1 | 1 | Flies, dives at player | `#1a1226` |
| Mini-Boss | 15 | 3 | Mid-stage gatekeeper, drops good weapon | `#6e2153` |

Enemy faces use the `enemies.config.json` mapping. Render as circle clipped to the head slot.

### Bosses

One boss per stage. They have a name banner, 2-phase HP bar, and unique attack patterns:

1. **Stage 1 — MOD_JENNY** (rogue mod) — throws timeout-hammers in arcs.
2. **Stage 2 — SIR_PINGS** (lag knight) — teleport-strikes with ping-delay tells.
3. **Stage 3 — KRAKEN_88** (sea miniboss) — rises from the pit, tentacle sweeps.
4. **Stage 4 — WARDEN_VIRGIL** (gate keeper) — shield bash, summons spam bots.
5. **Stage 5 — RNG_GHOUL** (loot ghoul) — drops a random weapon every 10s, but cursed.
6. **Stage 6 — THE DREADMOD** (final) — 3 phases: staff slams → magenta beam → throne demolition. Hero must use the Cursed Key, which spawns mid-fight.

Boss UI: banner with name in big Bangers font, HP bar with phase indicator ("PHASE 02 · ENRAGED").

## File structure to create

```
/
  index.html
  styles.css
  /js
    main.js              -- Phaser bootstrap, scene registry
    scenes/
      BootScene.js       -- asset preload
      TitleScene.js
      StoryScene.js      -- 6 comic panels w/ typewriter captions
      StageSelectScene.js
      GameScene.js       -- the platformer
      BossScene.js       -- extends GameScene with boss logic
      StageClearScene.js
      GameOverScene.js
      VictoryScene.js
      PauseScene.js
    entities/
      Hero.js
      Enemy.js
      Boss.js
      Weapon.js
      Pickup.js
      Obstacle.js
    systems/
      ComboSystem.js
      HypeSystem.js
      SaveSystem.js      -- localStorage wrapper
      ConfigLoader.js    -- loads enemies.config.json
    ui/
      HUD.js
      CaptionBox.js
      SFXBurst.js
      DialogueBubble.js
    data/
      stages.js          -- level layouts
      weapons.js
      enemies.js
      bosses.js
  /assets
    hero.png
    castle-bg.png
    (room for more)
  /faces
    README.md            -- "drop player photos here, update enemies.config.json"
  enemies.config.json
```

## Implementation order

Build in this order; each step should be playable before moving on:

1. **Boot + Title + Stage Select navigation** — clickable, persists progress.
2. **GameScene skeleton** — hero walks, jumps, falls, basic ground + parallax castle bg.
3. **Multi-tier platforms** — stairs, floating slabs, drop-through, pit deaths.
4. **HUD** — hearts, hype bar, score, combo, stage progress.
5. **One enemy type (Pleb Troll)** + combat — swing → hit → knockback → SFX burst.
6. **Pickups** — heart, energy drink, sub token. Crates that smash.
7. **Weapons** — pick up, swing, throw, durability, break.
8. **Remaining enemy types** including ranged Hater and flying Ghost Bat.
9. **Mini-boss** mid-stage.
10. **Stage boss** + Boss UI banner + multi-phase HP.
11. **Stage clear / game over scenes**.
12. **Story intro** comic panels.
13. **All 6 stages** with thematic level data.
14. **Final boss** (Dreadmod) + victory scene.
15. **Polish** — camera shake, particle SFX, screen flash on hit, sound effects.

## Code style

- ES modules, one class per file.
- No TypeScript.
- Prefer composition over inheritance for entities.
- All "magic numbers" (damage, HP, speeds) live in `/data/*.js` config files so they're easy to balance.
- Comment any non-obvious physics/timing values.

## Important constraints

- **The game must run by opening `index.html` directly** in a browser. No `npm`, no bundler.
- **Match the comic-pulp visual style at all times.** Every UI element gets the 3–4px black outline + offset drop shadow. Hits spawn SFX bursts. Caption boxes for narration. Never use generic UI defaults.
- **Player faces must be hot-swappable.** Editing `enemies.config.json` and dropping a new `.png` in `/faces` should change an enemy's face on reload — no code changes required.
- **All text the player sees lives in one strings file** (`/data/strings.js`) so it can be re-translated easily.

## When you're done

Provide a short `README.md` covering:
- How to run (just open `index.html`).
- How to add player faces (drop in `/faces/`, edit `enemies.config.json`).
- How to tune difficulty (edit `/data/enemies.js`, `/data/weapons.js`).
- Keyboard controls.

---

Reference the visual pitch in `Bakhira Game Design.html` whenever in doubt about how a screen should look. **Match it; don't reinterpret it.**

Now go build something incredible.
