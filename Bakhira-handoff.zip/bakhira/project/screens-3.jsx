/* Weapons & pickups catalog + Boss fight + Endings */

const WeaponsCatalog = () => {
  const weapons = [
    { name: "BAT",          tag: "STARTER · MELEE",   dmg: 2, spd: 3, dur: 100, color: "#8a5a30", icon: "▬", desc: "His own bat. Reliable. Sentimental.", rar: "COMMON" },
    { name: "KEYBOARD",     tag: "THROWN · LIGHT",    dmg: 1, spd: 5, dur: 30,  color: "#2a2a35", icon: "⌨", desc: "Mechanical. Loud. One-time use.", rar: "COMMON" },
    { name: "MIC STAND",    tag: "MELEE · REACH",     dmg: 3, spd: 2, dur: 80,  color: "#5a5a66", icon: "🎤", desc: "Long reach. Stuns trolls mid-rant.", rar: "UNCOMMON" },
    { name: "RGB SWORD",    tag: "MELEE · CRIT",      dmg: 4, spd: 3, dur: 60,  color: "#5fb6c8", icon: "⚔", desc: "Glows. Crits land on subscribers.", rar: "RARE" },
    { name: "DONO ROCKET",  tag: "RANGED · EXPLOSIVE",dmg: 5, spd: 4, dur: 5,   color: "#c8323a", icon: "🚀", desc: "Five shots. Loud applause on impact.", rar: "RARE" },
    { name: "BANHAMMER",    tag: "HEAVY · AOE",       dmg: 5, spd: 1, dur: 40,  color: "#e8b04a", icon: "🔨", desc: "Slow swing. Bans every mob on hit.", rar: "EPIC" },
    { name: "CURSED KEY",   tag: "SPECIAL · BOSS",    dmg: 6, spd: 2, dur: 1,   color: "#c44a8c", icon: "🗝", desc: "One swing. Reserved for The Dreadmod.", rar: "LEGENDARY" },
  ];

  const pickups = [
    { name: "HEART",        what: "+1 HP",           col: "var(--blood)",  icon: "♥" },
    { name: "ENERGY DRINK", what: "+25 HYPE",        col: "var(--curse)",  icon: "▮" },
    { name: "PIZZA SLICE",  what: "+2 HP (rare)",    col: "var(--gold)",   icon: "▲" },
    { name: "SUB TOKEN",    what: "+1000 SCORE",     col: "var(--cyan)",   icon: "$" },
    { name: "EXTRA LIFE",   what: "+1 LIFE",         col: "var(--green)",  icon: "★" },
    { name: "CHAT SHIELD",  what: "10s INVULN",      col: "var(--paper)",  icon: "◆" },
  ];

  const Dot = ({ filled }) => (
    <span style={{ width: 10, height: 10, borderRadius: "50%", background: filled ? "var(--ink)" : "transparent", border: "2px solid var(--ink)", display: "inline-block", marginRight: 3 }} />
  );

  const rarColor = (r) => ({
    COMMON: "#9aa0a8",
    UNCOMMON: "var(--green)",
    RARE: "var(--cyan)",
    EPIC: "var(--curse)",
    LEGENDARY: "var(--gold)"
  })[r];

  return (
    <div style={{ width: "100%", height: "100%", background: "var(--paper)", padding: 28, position: "relative", overflow: "hidden" }} className="halftone-light">
      {/* Header */}
      <div style={{ display: "flex", alignItems: "flex-end", justifyContent: "space-between", marginBottom: 18 }}>
        <div>
          <div className="chip" style={{ marginBottom: 6 }}>06 · WEAPONS & PICKUPS</div>
          <div className="t-display" style={{ fontSize: 48, lineHeight: 0.9 }}>
            ARMORY <span style={{ color: "var(--curse)" }}>&</span> LOOT
          </div>
        </div>
        <div className="caption" style={{ maxWidth: 340 }}>
          WEAPONS BREAK ON USE — DURABILITY DRIVES THE LOOP.
          GRAB WHATEVER'S ON THE GROUND, SWING IT TILL IT SNAPS.
        </div>
      </div>

      {/* Weapons grid */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 14, marginBottom: 18 }}>
        {weapons.map((w) => (
          <div key={w.name} className="tile" style={{ padding: 0, display: "flex", flexDirection: "column", overflow: "hidden" }}>
            {/* art */}
            <div style={{ height: 110, background: "linear-gradient(180deg, var(--night-3), var(--night))", position: "relative", borderBottom: "3px solid var(--ink)", overflow: "hidden" }}>
              <div className="halftone" style={{ position: "absolute", inset: 0, opacity: 0.3 }} />
              <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 60, color: w.color, textShadow: "3px 3px 0 var(--ink), 0 0 30px " + w.color }}>
                {w.icon}
              </div>
              <div className="chip" style={{ position: "absolute", top: 6, left: 6, background: rarColor(w.rar), color: "var(--ink)", fontSize: 10 }}>
                {w.rar}
              </div>
            </div>
            {/* info */}
            <div style={{ padding: "8px 10px", flex: 1 }}>
              <div className="t-display" style={{ fontSize: 22, lineHeight: 1 }}>{w.name}</div>
              <div className="t-mono" style={{ fontSize: 11, opacity: 0.7, marginTop: 2 }}>{w.tag}</div>
              <div className="t-type" style={{ fontSize: 11, marginTop: 6, minHeight: 32 }}>{w.desc}</div>
              <div style={{ marginTop: 6, fontSize: 10, fontFamily: "Special Elite, monospace", display: "grid", gridTemplateColumns: "48px 1fr", rowGap: 3 }}>
                <span>DMG</span>
                <span>{[1,2,3,4,5,6].map(i => <Dot key={i} filled={i <= w.dmg} />)}</span>
                <span>SPD</span>
                <span>{[1,2,3,4,5].map(i => <Dot key={i} filled={i <= w.spd} />)}</span>
                <span>DUR</span>
                <span style={{ alignSelf: "center" }}>{w.dur}</span>
              </div>
            </div>
          </div>
        ))}
        {/* +slot for unknown */}
        <div className="tile" style={{ padding: 0, display: "flex", flexDirection: "column", overflow: "hidden", background: "repeating-linear-gradient(45deg, var(--paper) 0 12px, var(--paper-2) 12px 24px)" }}>
          <div style={{ height: 110, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 50, color: "var(--ink)", opacity: 0.4 }}>?</div>
          <div style={{ padding: 10, flex: 1, textAlign: "center" }}>
            <div className="t-display" style={{ fontSize: 22 }}>SECRET SLOT</div>
            <div className="t-mono" style={{ fontSize: 11, opacity: 0.6 }}>UNLOCK ON CASTLE GATES</div>
          </div>
        </div>
      </div>

      {/* Pickups row */}
      <div className="panel" style={{ padding: 14 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 14, marginBottom: 10 }}>
          <div className="t-display" style={{ fontSize: 28 }}>CONSUMABLE PICKUPS</div>
          <div className="t-mono" style={{ fontSize: 12, opacity: 0.6 }}>SPAWN ON KILL · ON CRATE-SMASH · IN HIDDEN ROOMS</div>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(6, 1fr)", gap: 10 }}>
          {pickups.map(p => (
            <div key={p.name} style={{ display: "flex", alignItems: "center", gap: 10, padding: 8, border: "2px solid var(--ink)", background: "var(--paper-2)" }}>
              <div style={{ width: 42, height: 42, background: p.col, border: "3px solid var(--ink)", display: "flex", alignItems: "center", justifyContent: "center", color: "var(--ink)", fontFamily: "Bangers, sans-serif", fontSize: 22 }}>
                {p.icon}
              </div>
              <div>
                <div className="t-cond" style={{ fontSize: 14, letterSpacing: "0.1em" }}>{p.name}</div>
                <div className="t-mono" style={{ fontSize: 11, opacity: 0.8 }}>{p.what}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

const BossFight = () => (
  <div style={{ width: "100%", height: "100%", position: "relative", overflow: "hidden", background: "var(--ink)" }} className="scanlines">
    {/* Throne bg */}
    <div style={{ position: "absolute", inset: 0, background: "radial-gradient(ellipse at 70% 50%, var(--curse-deep) 0%, #2a0e22 35%, var(--ink) 80%)" }} />
    <div className="halftone" style={{ position: "absolute", inset: 0, opacity: 0.25 }} />
    {/* gothic windows */}
    {[0,1,2].map(i => (
      <div key={i} style={{ position: "absolute", top: "12%", left: `${15 + i*30}%`, width: 80, height: 160, background: "linear-gradient(180deg, var(--caption) 0%, var(--curse) 100%)", borderRadius: "40px 40px 0 0", border: "4px solid var(--ink)", boxShadow: "0 0 30px var(--caption)", opacity: 0.7 }} />
    ))}
    {/* ground */}
    <div style={{ position: "absolute", left: 0, right: 0, bottom: 0, height: 120, background: "linear-gradient(180deg, #2a1226 0%, #14081a 100%)", borderTop: "4px solid var(--ink)" }} />
    <div style={{ position: "absolute", left: 0, right: 0, bottom: 110, height: 14, background: "repeating-linear-gradient(90deg, var(--curse-deep) 0 28px, #3a1230 28px 56px)", borderTop: "3px solid var(--ink)", borderBottom: "3px solid var(--ink)" }} />

    {/* HERO bottom-left, smaller scale */}
    <img src="assets/hero.png" style={{ position: "absolute", bottom: 110, left: "12%", height: "36%", zIndex: 5, filter: "drop-shadow(5px 0 0 var(--ink))" }} />

    {/* BOSS — silhouette giant on right */}
    <div style={{ position: "absolute", bottom: 110, right: "10%", width: 280, height: "70%", zIndex: 4 }}>
      {/* throne */}
      <div style={{ position: "absolute", bottom: 0, left: "50%", transform: "translateX(-50%)", width: 240, height: 80, background: "var(--ink)", border: "3px solid var(--curse)" }} />
      {/* body */}
      <div style={{ position: "absolute", bottom: 60, left: "50%", transform: "translateX(-50%)", width: 200, height: "70%", background: "linear-gradient(180deg, #2a0e22, #14081a)", clipPath: "polygon(40% 0, 60% 0, 78% 18%, 95% 100%, 5% 100%, 22% 18%)", border: "3px solid var(--curse)" }} />
      {/* head */}
      <div style={{ position: "absolute", top: 30, left: "50%", transform: "translateX(-50%)", width: 110, height: 110, background: "var(--ink)", border: "3px solid var(--curse)", clipPath: "polygon(30% 0, 70% 0, 100% 30%, 100% 80%, 50% 100%, 0 80%, 0 30%)" }} />
      {/* glowing eyes */}
      <div style={{ position: "absolute", top: 85, left: "calc(50% - 25px)", width: 14, height: 6, background: "var(--caption)", boxShadow: "0 0 20px var(--caption)" }} />
      <div style={{ position: "absolute", top: 85, left: "calc(50% + 11px)", width: 14, height: 6, background: "var(--caption)", boxShadow: "0 0 20px var(--caption)" }} />
      {/* staff */}
      <div style={{ position: "absolute", bottom: 60, right: "0%", width: 8, height: "75%", background: "linear-gradient(180deg, var(--curse), var(--ink))", border: "2px solid var(--ink)" }} />
      <div style={{ position: "absolute", top: 40, right: "-4%", width: 30, height: 30, borderRadius: "50%", background: "radial-gradient(circle, var(--caption), var(--curse))", border: "3px solid var(--ink)", boxShadow: "0 0 30px var(--caption)" }} />
    </div>

    {/* Captive GF (small, in a cage hung from ceiling) */}
    <div style={{ position: "absolute", top: 60, right: "30%", zIndex: 6 }}>
      <div style={{ width: 4, height: 60, background: "var(--ink)", margin: "0 auto" }} />
      <div style={{ width: 80, height: 90, border: "4px solid var(--ink)", background: "rgba(20,8,26,0.6)", position: "relative" }}>
        {/* bars */}
        <div style={{ position: "absolute", inset: 4, background: "repeating-linear-gradient(90deg, transparent 0 8px, var(--ink) 8px 11px)" }} />
        {/* figure inside */}
        <div style={{ position: "absolute", inset: "20% 28%", background: "linear-gradient(180deg, #f5db7a, #c44a8c)", borderRadius: "20% 20% 0 0" }} />
      </div>
      <div className="bubble" style={{ position: "absolute", top: 0, right: -180, fontSize: 13, maxWidth: 160, padding: "5px 10px" }}>
        "GET ME OUTTA HERE!!"
      </div>
    </div>

    {/* HUD */}
    {/* Boss name banner top */}
    <div style={{ position: "absolute", top: 18, left: "50%", transform: "translateX(-50%)", zIndex: 20, textAlign: "center" }}>
      <div className="chip" style={{ background: "var(--curse)", color: "var(--paper)", marginBottom: 6 }}>FINAL BOSS · STAGE 06</div>
      <div className="t-display" style={{ fontSize: 56, color: "var(--paper)", lineHeight: 0.9, WebkitTextStroke: "3px var(--ink)", textShadow: "5px 5px 0 var(--curse-deep), 5px 5px 0 var(--ink)", letterSpacing: "0.03em" }}>
        THE DREADMOD
      </div>
      {/* boss HP */}
      <div style={{ width: 540, height: 22, background: "var(--ink)", border: "3px solid var(--paper)", margin: "10px auto 0", position: "relative" }}>
        <div style={{ position: "absolute", inset: 0, width: "72%", background: "linear-gradient(90deg, var(--curse), var(--blood))" }} />
        <div className="t-cond" style={{ position: "absolute", inset: 0, color: "var(--paper)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 13, letterSpacing: "0.2em" }}>
          PHASE 02 · ENRAGED
        </div>
      </div>
    </div>

    {/* Boss SFX */}
    <div style={{ position: "absolute", top: "40%", right: "30%", zIndex: 8, transform: "rotate(-10deg)" }}>
      <span className="sfx" style={{ fontSize: 64, color: "var(--curse)" }}>CLACK!!</span>
    </div>
    <div style={{ position: "absolute", top: "55%", left: "30%", zIndex: 8, transform: "rotate(8deg)" }}>
      <span className="sfx" style={{ fontSize: 48, color: "var(--blood)" }}>KRRSH!</span>
    </div>

    {/* Bottom hero HUD */}
    <div style={{ position: "absolute", bottom: 18, left: 18, zIndex: 20, display: "flex", gap: 10, alignItems: "center" }}>
      <div className="panel-dark" style={{ padding: "6px 12px", background: "var(--ink)", borderColor: "var(--paper)" }}>
        <div className="t-cond" style={{ fontSize: 12, color: "var(--paper)", letterSpacing: "0.18em" }}>BAKHIRA</div>
        <div style={{ display: "flex", gap: 3, marginTop: 4 }}>
          <span className="heart" /><span className="heart" /><span className="heart empty" /><span className="heart empty" /><span className="heart empty" />
        </div>
        <div style={{ width: 160, height: 8, background: "var(--ink-2)", border: "2px solid var(--paper)", marginTop: 6 }}>
          <div style={{ width: "100%", height: "100%", background: "linear-gradient(90deg, var(--curse), var(--caption))" }} />
        </div>
        <div className="t-mono" style={{ fontSize: 10, color: "var(--caption)", marginTop: 2 }}>HYPE FULL · TAP Y</div>
      </div>
      <div className="tile" style={{ width: 70, height: 70, background: "var(--paper)", padding: 0, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 30, color: "var(--curse)" }}>🗝</div>
    </div>
  </div>
);

const Endings = () => (
  <div style={{ width: "100%", height: "100%", display: "grid", gridTemplateColumns: "1fr 1fr", gap: 0, position: "relative", background: "var(--ink)" }}>
    {/* Game Over */}
    <div style={{ position: "relative", overflow: "hidden", borderRight: "4px solid var(--ink)" }} className="scanlines">
      <div style={{ position: "absolute", inset: 0, background: "radial-gradient(ellipse at center, #2a0e14 0%, #0a0608 80%)" }} />
      <div className="halftone" style={{ position: "absolute", inset: 0, opacity: 0.3 }} />
      <div style={{ position: "absolute", inset: 0, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", padding: 30, zIndex: 5 }}>
        <div className="t-display" style={{ fontSize: 90, lineHeight: 0.9, color: "var(--blood)", WebkitTextStroke: "4px var(--ink)", textShadow: "6px 6px 0 var(--ink), 6px 6px 0 #5a0a10", letterSpacing: "0.04em" }}>
          STREAM<br/>ENDED.
        </div>
        <div className="caption" style={{ marginTop: 20, background: "var(--blood)", color: "var(--paper)", maxWidth: 280, textAlign: "center" }}>
          THE TROLLS GOT YOU.<br/>SHE'S STILL IN THERE.
        </div>
        <div style={{ marginTop: 18, display: "flex", gap: 10 }}>
          <div className="btn-comic primary">↻ RETRY</div>
          <div className="btn-comic">QUIT</div>
        </div>
        <div className="t-mono" style={{ marginTop: 18, fontSize: 12, color: "var(--paper)", opacity: 0.6, letterSpacing: "0.2em" }}>
          STAGE 03 · DEATHS THIS RUN · 04
        </div>
      </div>
      {/* fallen hero silhouette */}
      <img src="assets/hero.png" style={{ position: "absolute", bottom: 20, right: 20, height: 100, filter: "brightness(0.2) grayscale(1) drop-shadow(0 0 12px var(--blood))", transform: "rotate(75deg)", opacity: 0.8 }} />
    </div>

    {/* Stage Clear / Victory */}
    <div style={{ position: "relative", overflow: "hidden" }} className="scanlines">
      <div style={{ position: "absolute", inset: 0, background: "radial-gradient(ellipse at center, #2a2014 0%, var(--ink) 80%)" }} />
      <div className="starburst" style={{ position: "absolute", width: 700, height: 700, top: "50%", left: "50%", transform: "translate(-50%, -50%)", opacity: 0.5, borderRadius: "50%" }} />
      <div className="halftone" style={{ position: "absolute", inset: 0, opacity: 0.2 }} />

      <div style={{ position: "absolute", inset: 0, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", padding: 30, zIndex: 5 }}>
        <div className="chip" style={{ background: "var(--caption)", color: "var(--ink)" }}>STAGE 03 CLEARED</div>
        <div className="t-display" style={{ fontSize: 90, lineHeight: 0.9, color: "var(--caption)", WebkitTextStroke: "4px var(--ink)", textShadow: "6px 6px 0 var(--ink), 6px 6px 0 var(--curse-deep)", letterSpacing: "0.04em", marginTop: 8 }}>
          KNOCKOUT!
        </div>
        {/* Score breakdown */}
        <div className="panel" style={{ marginTop: 18, padding: "12px 18px", minWidth: 320 }}>
          <div className="t-cond" style={{ fontSize: 14, letterSpacing: "0.2em", marginBottom: 8 }}>STAGE TALLY</div>
          <div style={{ fontFamily: "VT323, monospace", fontSize: 18, lineHeight: 1.4 }}>
            <div style={{ display: "flex", justifyContent: "space-between" }}><span>KILLS</span><span>x 23</span></div>
            <div style={{ display: "flex", justifyContent: "space-between" }}><span>BEST COMBO</span><span>x 18</span></div>
            <div style={{ display: "flex", justifyContent: "space-between" }}><span>SUB TOKENS</span><span>x 7</span></div>
            <div style={{ display: "flex", justifyContent: "space-between" }}><span>HP REMAINING</span><span>3 / 5</span></div>
            <div style={{ borderTop: "2px solid var(--ink)", marginTop: 4, paddingTop: 4, display: "flex", justifyContent: "space-between", fontFamily: "Bangers, sans-serif", fontSize: 22 }}>
              <span>TOTAL</span><span style={{ color: "var(--curse)" }}>+ 0 24 500</span>
            </div>
          </div>
        </div>
        <div style={{ marginTop: 14, display: "flex", gap: 10 }}>
          <div className="btn-comic primary">▶ NEXT STAGE</div>
          <div className="btn-comic">MAP</div>
        </div>
      </div>

      <div style={{ position: "absolute", top: 20, right: 30, transform: "rotate(8deg)", zIndex: 6 }}>
        <span className="sfx" style={{ fontSize: 56, color: "var(--blood)" }}>BANG!</span>
      </div>
    </div>
  </div>
);

window.WeaponsCatalog = WeaponsCatalog;
window.BossFight = BossFight;
window.Endings = Endings;
