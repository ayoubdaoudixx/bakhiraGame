/* Brand sheet — logo, palette, type, hero character */

const BrandSheet = () => (
  <div style={{ width: "100%", height: "100%", background: "var(--paper)", padding: "32px", position: "relative", overflow: "hidden" }} className="halftone-light">
    {/* Title strip */}
    <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", marginBottom: 24 }}>
      <div>
        <div className="chip" style={{ marginBottom: 10 }}>01 · BRAND & HERO</div>
        <div className="t-display" style={{ fontSize: 64, lineHeight: 0.9, color: "var(--ink)" }}>
          BAKHIRA<span style={{ color: "var(--curse)" }}>.</span>
        </div>
        <div className="t-cond" style={{ fontSize: 18, letterSpacing: "0.18em", color: "var(--ink)", marginTop: 4 }}>
          THE CURSED STREAM · A SIDE-SCROLLING BRAWLER
        </div>
      </div>
      <div className="caption" style={{ maxWidth: 360 }}>
        Game pitch · v0.1 · The streamer's girl was taken. The chat went dark.
        Now he swings a bat and the curse swings back.
      </div>
    </div>

    {/* Grid */}
    <div style={{ display: "grid", gridTemplateColumns: "420px 1fr 1fr", gap: 24, height: "calc(100% - 130px)" }}>
      {/* Hero card */}
      <div className="panel" style={{ padding: 0, position: "relative" }}>
        <div style={{ position: "absolute", inset: 0, background: "linear-gradient(180deg, var(--night-3) 0%, var(--night) 70%, var(--ink) 100%)" }} />
        <div className="halftone" style={{ position: "absolute", inset: 0, opacity: 0.3 }} />
        {/* big star behind */}
        <div className="starburst" style={{ position: "absolute", width: 380, height: 380, top: 60, left: -40, opacity: 0.35, borderRadius: "50%" }} />
        <img src="assets/hero.png" style={{ position: "absolute", bottom: 0, left: "50%", transform: "translateX(-50%)", height: "92%", filter: "drop-shadow(0 8px 0 rgba(0,0,0,0.5))" }} />
        <div style={{ position: "absolute", top: 18, left: 18 }}>
          <div className="chip" style={{ background: "var(--blood)", color: "var(--paper)" }}>HERO · PLAYER 1</div>
        </div>
        <div style={{ position: "absolute", bottom: 18, left: 18, right: 18 }}>
          <div className="bubble" style={{ display: "inline-block", maxWidth: "85%" }}>
            "WHERE'S MY GIRL,<br/>YOU NERDS?!"
          </div>
        </div>
        <div style={{ position: "absolute", top: 100, right: -14 }}>
          <span className="sfx" style={{ fontSize: 56, color: "var(--curse)" }}>BAKHIRA!</span>
        </div>
      </div>

      {/* Stats / abilities */}
      <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
        <div className="panel" style={{ padding: 18 }}>
          <div className="t-display" style={{ fontSize: 30, lineHeight: 1, marginBottom: 12 }}>STAT SHEET</div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr auto", rowGap: 8, columnGap: 12, fontFamily: "Special Elite, monospace", fontSize: 14 }}>
            <div>VITALITY</div><div>●●●●○</div>
            <div>STRENGTH</div><div>●●●●●</div>
            <div>SPEED</div><div>●●○○○</div>
            <div>CHARISMA</div><div>●●●●●</div>
            <div>CURSE RESIST</div><div>●○○○○</div>
          </div>
        </div>
        <div className="panel" style={{ padding: 18, flex: 1 }}>
          <div className="t-display" style={{ fontSize: 30, lineHeight: 1, marginBottom: 12 }}>SIGNATURE MOVES</div>
          <div style={{ display: "flex", flexDirection: "column", gap: 10, fontFamily: "Special Elite, monospace", fontSize: 13 }}>
            <div style={{ display: "flex", gap: 10, alignItems: "flex-start" }}>
              <span className="chip" style={{ minWidth: 52, textAlign: "center" }}>X</span>
              <div><b>BAT SWING</b> — basic combo, 3 hits then knockback.</div>
            </div>
            <div style={{ display: "flex", gap: 10, alignItems: "flex-start" }}>
              <span className="chip" style={{ minWidth: 52, textAlign: "center", background: "var(--curse)" }}>Y</span>
              <div><b>HYPE RAID</b> — chat-fueled spin attack. Costs HYPE bar.</div>
            </div>
            <div style={{ display: "flex", gap: 10, alignItems: "flex-start" }}>
              <span className="chip" style={{ minWidth: 52, textAlign: "center", background: "var(--blood)" }}>B</span>
              <div><b>DODGE ROLL</b> — invincible frames, knocks over small mobs.</div>
            </div>
            <div style={{ display: "flex", gap: 10, alignItems: "flex-start" }}>
              <span className="chip" style={{ minWidth: 52, textAlign: "center", background: "var(--gold)", color: "var(--ink)" }}>A</span>
              <div><b>JUMP</b> — double-tap to dash. Land on a head = bonus.</div>
            </div>
          </div>
        </div>
      </div>

      {/* Palette + type */}
      <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
        <div className="panel" style={{ padding: 18 }}>
          <div className="t-display" style={{ fontSize: 30, lineHeight: 1, marginBottom: 12 }}>PALETTE</div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 8 }}>
            {[
              ["#0a0a12","INK"],
              ["#efe7d3","PAPER"],
              ["#f5db7a","CAPTION"],
              ["#c44a8c","CURSE"],
              ["#c8323a","BLOOD"],
              ["#0d1628","NIGHT"],
              ["#e8b04a","GOLD"],
              ["#5fb6c8","CYAN"],
            ].map(([c, n]) => (
              <div key={n} style={{ border: "2px solid var(--ink)", boxShadow: "2px 2px 0 var(--ink)" }}>
                <div style={{ background: c, height: 36 }} />
                <div style={{ fontFamily: "Special Elite, monospace", fontSize: 10, padding: "3px 5px", background: "var(--paper)", borderTop: "2px solid var(--ink)" }}>
                  {n}<br/><span style={{ opacity: 0.6 }}>{c}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
        <div className="panel" style={{ padding: 18, flex: 1 }}>
          <div className="t-display" style={{ fontSize: 30, lineHeight: 1, marginBottom: 12 }}>TYPE</div>
          <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
            <div>
              <div style={{ fontSize: 10, fontFamily: "Special Elite, monospace", opacity: 0.6 }}>DISPLAY · BANGERS</div>
              <div className="t-display" style={{ fontSize: 36, lineHeight: 1 }}>BANG! POW! BOSS!</div>
            </div>
            <div>
              <div style={{ fontSize: 10, fontFamily: "Special Elite, monospace", opacity: 0.6 }}>SHOUT · BUNGEE</div>
              <div className="t-shout" style={{ fontSize: 22, lineHeight: 1 }}>STAGE CLEAR</div>
            </div>
            <div>
              <div style={{ fontSize: 10, fontFamily: "Special Elite, monospace", opacity: 0.6 }}>UI · OSWALD COND.</div>
              <div className="t-cond" style={{ fontSize: 18, letterSpacing: "0.1em" }}>HEALTH · SCORE · STAGE 01</div>
            </div>
            <div>
              <div style={{ fontSize: 10, fontFamily: "Special Elite, monospace", opacity: 0.6 }}>BODY · SPECIAL ELITE</div>
              <div className="t-type" style={{ fontSize: 13 }}>
                Caption boxes use a typewriter face — keeps the pulp-comic feel.
              </div>
            </div>
            <div>
              <div style={{ fontSize: 10, fontFamily: "Special Elite, monospace", opacity: 0.6 }}>HUD · VT323 (PIXEL)</div>
              <div className="t-mono" style={{ fontSize: 22 }}>SCORE 0124500 · x3</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
);

window.BrandSheet = BrandSheet;
