/* Gameplay HUD — Cactus McCoy-style multi-tier path through the coastal castle */

const GameplayHUD = () => (
  <div style={{ width: "100%", height: "100%", position: "relative", overflow: "hidden", background: "var(--ink)" }} className="scanlines">
    {/* ===== PARALLAX BACKGROUND ===== */}
    {/* Sky / moon */}
    <div style={{ position: "absolute", inset: 0, background: "linear-gradient(180deg, #1a2540 0%, #0d1628 60%, #0a0a12 100%)" }} />
    <div style={{ position: "absolute", top: 60, left: 140, width: 70, height: 70, borderRadius: "50%", background: "radial-gradient(circle at 35% 35%, var(--paper), var(--bone))", boxShadow: "0 0 50px rgba(245,219,122,0.4)" }} />
    {/* clouds */}
    <div style={{ position: "absolute", top: 90, left: "30%", width: 200, height: 30, background: "rgba(40,55,90,0.7)", borderRadius: 20, filter: "blur(3px)" }} />
    <div style={{ position: "absolute", top: 140, left: "60%", width: 260, height: 26, background: "rgba(40,55,90,0.5)", borderRadius: 20, filter: "blur(4px)" }} />

    {/* Distant castle silhouette */}
    <div style={{ position: "absolute", inset: 0, backgroundImage: "url('assets/castle-bg.png')", backgroundSize: "cover", backgroundPosition: "60% 30%", filter: "brightness(0.4) saturate(0.6)", opacity: 0.55, mixBlendMode: "screen" }} />
    {/* darken bottom */}
    <div style={{ position: "absolute", inset: 0, background: "linear-gradient(180deg, transparent 0%, transparent 40%, rgba(10,10,18,0.75) 80%, rgba(10,10,18,0.95) 100%)" }} />

    {/* Distant sea on left */}
    <div style={{ position: "absolute", bottom: 0, left: 0, width: "30%", height: "30%", background: "linear-gradient(180deg, rgba(95,182,200,0.15) 0%, rgba(13,22,40,0.6) 100%)", clipPath: "polygon(0 30%, 100% 50%, 100% 100%, 0 100%)" }} />
    {/* wave glints */}
    <div style={{ position: "absolute", bottom: "10%", left: "4%", width: 80, height: 2, background: "var(--paper)", opacity: 0.4, transform: "rotate(-2deg)" }} />
    <div style={{ position: "absolute", bottom: "15%", left: "10%", width: 60, height: 2, background: "var(--paper)", opacity: 0.3 }} />

    {/* ===== LEVEL GEOMETRY — multi-tier cliff path ===== */}

    {/* LOW PATH — sandy/rocky cliffside walkway */}
    <div style={{ position: "absolute", left: 0, right: 0, bottom: 0, height: 110, background: "linear-gradient(180deg, #2a2018 0%, #1a120c 100%)", borderTop: "4px solid var(--ink)" }} />
    {/* cobble strip on low path */}
    <div style={{ position: "absolute", left: 0, right: 0, bottom: 100, height: 14, background: "repeating-linear-gradient(90deg, #3a2818 0 22px, #2a1f12 22px 44px)", borderTop: "3px solid var(--ink)", borderBottom: "3px solid var(--ink)" }} />

    {/* MID PLATFORM — ruined rampart on the right */}
    <div style={{ position: "absolute", right: "0%", bottom: 180, width: "45%", height: 90, background: "linear-gradient(180deg, #2a2530 0%, #14101a 100%)", borderTop: "4px solid var(--ink)", borderLeft: "4px solid var(--ink)" }}>
      {/* stones */}
      <div style={{ position: "absolute", inset: 0, background: "repeating-linear-gradient(90deg, transparent 0 38px, rgba(0,0,0,0.4) 38px 41px), repeating-linear-gradient(0deg, transparent 0 22px, rgba(0,0,0,0.3) 22px 24px)" }} />
      {/* battlements (crenellations) */}
      <div style={{ position: "absolute", top: -16, left: 0, right: 0, height: 16, background: "repeating-linear-gradient(90deg, var(--ink) 0 24px, transparent 24px 48px)" }} />
    </div>
    {/* broken edge of mid platform */}
    <div style={{ position: "absolute", left: "55%", bottom: 180, width: 26, height: 50, background: "var(--ink)", clipPath: "polygon(0 0, 100% 30%, 100% 100%, 0 100%)" }} />

    {/* HIGH PLATFORM — small tower top on left */}
    <div style={{ position: "absolute", left: "6%", bottom: 320, width: 200, height: 70, background: "linear-gradient(180deg, #2a2530, #14101a)", borderTop: "4px solid var(--ink)", border: "3px solid var(--ink)" }}>
      <div style={{ position: "absolute", inset: 0, background: "repeating-linear-gradient(0deg, transparent 0 16px, rgba(0,0,0,0.35) 16px 18px)" }} />
      {/* battlements */}
      <div style={{ position: "absolute", top: -14, left: 0, right: 0, height: 14, background: "repeating-linear-gradient(90deg, var(--ink) 0 20px, transparent 20px 40px)" }} />
    </div>

    {/* MID PLATFORM 2 — bridge between high and mid (floating slabs) */}
    <div style={{ position: "absolute", left: "30%", bottom: 260, width: 110, height: 22, background: "linear-gradient(180deg, #2a2530, #14101a)", border: "3px solid var(--ink)" }} />
    <div style={{ position: "absolute", left: "44%", bottom: 230, width: 90, height: 22, background: "linear-gradient(180deg, #2a2530, #14101a)", border: "3px solid var(--ink)" }} />

    {/* STAIRS down from mid-rampart to low path */}
    {[0,1,2,3,4].map(i => (
      <div key={i} style={{ position: "absolute", left: `${55 + i*2.4}%`, bottom: 110 + (4-i)*14, width: 50, height: 16, background: "#1f1820", border: "3px solid var(--ink)" }} />
    ))}

    {/* PIT — gap in the low path (with water/rocks below) */}
    <div style={{ position: "absolute", left: "78%", bottom: 0, width: 70, height: 100, background: "linear-gradient(180deg, transparent 0%, rgba(95,182,200,0.25) 30%, rgba(13,22,40,0.95) 100%)" }}>
      {/* jagged top edge */}
      <div style={{ position: "absolute", top: -3, left: -3, right: -3, height: 8, background: "var(--ink)", clipPath: "polygon(0 0, 8% 100%, 16% 0, 24% 100%, 32% 0, 40% 100%, 48% 0, 56% 100%, 64% 0, 72% 100%, 80% 0, 88% 100%, 96% 0, 100% 100%, 100% 0)" }} />
    </div>

    {/* ===== THEMED OBSTACLES ===== */}

    {/* SPIKE TRAP on low path */}
    <div style={{ position: "absolute", bottom: 110, left: "26%", display: "flex", gap: 0 }}>
      {[0,1,2,3].map(i => (
        <div key={i} style={{ width: 12, height: 22, background: "linear-gradient(180deg, #c4c4cc, #5a5a66)", clipPath: "polygon(50% 0, 100% 100%, 0 100%)", filter: "drop-shadow(1px 1px 0 var(--ink))" }} />
      ))}
    </div>

    {/* WOODEN CRATE on low path */}
    <div style={{ position: "absolute", bottom: 110, left: "60%", width: 46, height: 46, background: "linear-gradient(135deg, #8a5a30, #5a3a20)", border: "3px solid var(--ink)" }}>
      <div style={{ position: "absolute", inset: 6, border: "2px solid rgba(0,0,0,0.5)" }} />
      <div style={{ position: "absolute", top: "50%", left: -3, right: -3, height: 4, background: "var(--ink)" }} />
    </div>

    {/* BARREL on mid platform */}
    <div style={{ position: "absolute", bottom: 270, right: "10%", width: 38, height: 50, background: "linear-gradient(90deg, #6b4423, #8a5a30, #6b4423)", border: "3px solid var(--ink)", borderRadius: "6px / 14px" }}>
      <div style={{ position: "absolute", top: "30%", left: -3, right: -3, height: 3, background: "var(--ink)" }} />
      <div style={{ position: "absolute", top: "60%", left: -3, right: -3, height: 3, background: "var(--ink)" }} />
    </div>

    {/* TORCH on rampart wall */}
    <div style={{ position: "absolute", bottom: 230, right: "30%", width: 6, height: 30, background: "#6b4423", border: "2px solid var(--ink)" }} />
    <div style={{ position: "absolute", bottom: 252, right: "calc(30% - 8px)", width: 22, height: 28, background: "radial-gradient(ellipse at 50% 70%, #f5db7a 0%, #e8723a 50%, transparent 80%)", borderRadius: "50% 50% 30% 30%", filter: "drop-shadow(0 0 14px rgba(245,219,122,0.7))" }} />

    {/* GARGOYLE on tower */}
    <div style={{ position: "absolute", bottom: 390, left: "9%", width: 30, height: 26, background: "#2a2530", border: "2px solid var(--ink)", clipPath: "polygon(20% 100%, 0 60%, 20% 30%, 30% 0, 70% 0, 80% 30%, 100% 60%, 80% 100%)" }} />
    <div style={{ position: "absolute", bottom: 408, left: "10%", width: 4, height: 4, background: "var(--curse)", boxShadow: "0 0 6px var(--curse), 12px 0 0 var(--curse)" }} />

    {/* GHOSTLY BAT enemy — flying */}
    <div style={{ position: "absolute", top: 200, left: "44%", width: 40, height: 20 }}>
      <div style={{ width: 40, height: 20, background: "var(--ink)", clipPath: "polygon(0 60%, 15% 0, 30% 60%, 50% 30%, 70% 60%, 85% 0, 100% 60%, 100% 100%, 0 100%)" }} />
      <div style={{ position: "absolute", top: 6, left: 16, width: 8, height: 8, background: "var(--curse)", borderRadius: "50%", boxShadow: "0 0 8px var(--curse)" }} />
    </div>

    {/* ===== HERO on low path (about to climb stairs) ===== */}
    <img src="assets/hero.png" style={{ position: "absolute", bottom: 110, left: "14%", height: "38%", zIndex: 5, filter: "drop-shadow(6px 0 0 var(--ink)) drop-shadow(-3px 0 0 var(--ink))" }} />
    <div style={{ position: "absolute", bottom: "30%", left: "8%", zIndex: 4 }}>
      <span className="sfx" style={{ fontSize: 32, color: "var(--blood)" }}>WHACK!</span>
    </div>

    {/* ===== ENEMIES — placed at multiple tiers ===== */}
    {/* Mid-rampart bruiser */}
    <div style={{ position: "absolute", bottom: 270, right: "32%", zIndex: 4, display: "flex", flexDirection: "column", alignItems: "center" }}>
      <div className="face-slot" style={{ width: 62, height: 62, borderRadius: "50%" }}>[TROLL<br/>FACE 1]</div>
      <div style={{ width: 76, height: 70, background: "#3a2840", border: "3px solid var(--ink)", marginTop: -6, position: "relative" }}>
        <div style={{ position: "absolute", inset: 6, background: "repeating-linear-gradient(90deg, rgba(255,255,255,0.05) 0 3px, transparent 3px 7px)" }} />
        {/* weapon in hand */}
        <div style={{ position: "absolute", top: 20, right: -22, width: 24, height: 6, background: "#8a5a30", border: "2px solid var(--ink)", transform: "rotate(20deg)" }} />
      </div>
    </div>

    {/* Low-path mob — running at hero */}
    <div style={{ position: "absolute", bottom: 110, left: "42%", zIndex: 4, display: "flex", flexDirection: "column", alignItems: "center" }}>
      <div className="face-slot" style={{ width: 56, height: 56, borderRadius: "50%" }}>[TROLL<br/>FACE 2]</div>
      <div style={{ width: 70, height: 80, background: "#2a3a3f", border: "3px solid var(--ink)", marginTop: -6 }} />
    </div>

    {/* Mini-boss on far right ramparts */}
    <div style={{ position: "absolute", bottom: 270, right: "4%", zIndex: 4, display: "flex", flexDirection: "column", alignItems: "center" }}>
      <div className="face-slot" style={{ width: 80, height: 80, borderRadius: "50%", background: "linear-gradient(135deg, var(--curse-deep), var(--ink))" }}>[MINI<br/>BOSS]</div>
      <div style={{ width: 100, height: 90, background: "linear-gradient(180deg, var(--curse-deep), var(--ink))", border: "3px solid var(--curse)", marginTop: -8, position: "relative" }}>
        <div style={{ position: "absolute", top: -8, right: -16, width: 30, height: 6, background: "var(--gold)", border: "2px solid var(--ink)", transform: "rotate(-30deg)" }} />
      </div>
      <div className="chip" style={{ background: "var(--curse)", color: "var(--paper)", fontSize: 10, marginTop: 4 }}>MINI-BOSS</div>
    </div>

    {/* ===== PICKUPS lying on the path (Cactus McCoy style — grab as you go) ===== */}
    {/* Dropped weapon — keyboard */}
    <div style={{ position: "absolute", bottom: 115, left: "32%", zIndex: 4 }}>
      <div style={{ width: 50, height: 14, background: "#2a2a35", border: "3px solid var(--ink)", position: "relative", boxShadow: "0 0 12px rgba(95,182,200,0.5)" }}>
        <div style={{ position: "absolute", inset: 2, background: "repeating-linear-gradient(90deg, #5a5a66 0 4px, #2a2a35 4px 6px)" }} />
      </div>
      <div className="t-mono" style={{ fontSize: 10, color: "var(--cyan)", textAlign: "center", marginTop: 1 }}>⌨ KEYBOARD</div>
    </div>
    {/* Dropped weapon — pipe/baseball-bat-like on mid platform */}
    <div style={{ position: "absolute", bottom: 280, left: "32%", zIndex: 4 }}>
      <div style={{ width: 52, height: 9, background: "linear-gradient(90deg, #c4c4cc, #7a7a84)", border: "3px solid var(--ink)", transform: "rotate(-12deg)", boxShadow: "0 0 12px rgba(255,255,255,0.3)" }} />
    </div>
    {/* Heart pickup floating */}
    <div style={{ position: "absolute", bottom: 240, left: "47%", zIndex: 4, animation: "bob 1.2s infinite" }}>
      <div className="heart" style={{ width: 28, height: 28 }} />
    </div>
    {/* Energy drink hovering on tower */}
    <div style={{ position: "absolute", bottom: 405, left: "12%", zIndex: 4, animation: "bob 1s infinite" }}>
      <div style={{ width: 22, height: 32, background: "linear-gradient(180deg, var(--curse), var(--curse-deep))", border: "3px solid var(--ink)", boxShadow: "0 0 14px var(--curse)" }} />
    </div>
    {/* Sub tokens (gem-like) on stairs */}
    {[0,1,2].map(i => (
      <div key={i} style={{ position: "absolute", bottom: 170 + i*14, left: `${56 + i*2.4}%`, zIndex: 4, width: 14, height: 14, background: "var(--cyan)", border: "2px solid var(--ink)", transform: "rotate(45deg)", boxShadow: "0 0 10px var(--cyan)" }} />
    ))}

    {/* ===== HUD OVERLAY (simplified — no inventory) ===== */}
    {/* Top-left: hero portrait + HP + hype + lives */}
    <div style={{ position: "absolute", top: 18, left: 18, zIndex: 20 }}>
      <div className="panel-dark" style={{ padding: "8px 14px", background: "var(--ink)", borderColor: "var(--paper)", boxShadow: "4px 4px 0 var(--curse-deep)" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <div style={{ width: 48, height: 48, borderRadius: "50%", background: "var(--curse)", border: "3px solid var(--paper)", position: "relative", overflow: "hidden" }}>
            <img src="assets/hero.png" style={{ position: "absolute", width: 96, top: -4, left: -24 }} />
          </div>
          <div>
            <div className="t-cond" style={{ fontSize: 14, color: "var(--paper)", letterSpacing: "0.18em" }}>BAKHIRA</div>
            <div style={{ display: "flex", gap: 3, marginTop: 4 }}>
              <span className="heart" /><span className="heart" /><span className="heart" /><span className="heart empty" /><span className="heart empty" />
            </div>
            <div style={{ width: 170, height: 10, background: "var(--ink-2)", border: "2px solid var(--paper)", marginTop: 6, position: "relative" }}>
              <div style={{ position: "absolute", inset: 0, width: "62%", background: "linear-gradient(90deg, var(--curse), var(--caption))" }} />
              <div className="t-mono" style={{ position: "absolute", left: 6, top: -4, fontSize: 10, color: "var(--paper)", letterSpacing: "0.1em" }}>HYPE 62%</div>
            </div>
          </div>
        </div>
      </div>
      <div className="chip" style={{ background: "var(--caption)", color: "var(--ink)", marginTop: 6 }}>x3 LIVES</div>
    </div>

    {/* Top-center: stage info + progress to boss */}
    <div style={{ position: "absolute", top: 18, left: "50%", transform: "translateX(-50%)", zIndex: 20, textAlign: "center" }}>
      <div className="caption">STAGE 03 · COASTAL CLIFFS</div>
      <div style={{ width: 300, height: 12, background: "var(--ink)", border: "3px solid var(--paper)", marginTop: 6, position: "relative" }}>
        <div style={{ position: "absolute", left: 0, top: 0, bottom: 0, width: "38%", background: "var(--caption)" }} />
        <div style={{ position: "absolute", right: -2, top: -16, color: "var(--curse)", fontSize: 22 }}>👑</div>
        <div style={{ position: "absolute", left: "38%", top: -8, transform: "translateX(-50%)", width: 16, height: 16, background: "var(--blood)", border: "2px solid var(--paper)", borderRadius: "50%" }} />
      </div>
      <div className="t-mono" style={{ fontSize: 12, color: "var(--paper)", marginTop: 6, letterSpacing: "0.15em" }}>
        38% TO BOSS
      </div>
    </div>

    {/* Top-right: score + combo */}
    <div style={{ position: "absolute", top: 18, right: 18, zIndex: 20, textAlign: "right" }}>
      <div className="panel-dark" style={{ padding: "8px 14px", background: "var(--ink)", borderColor: "var(--paper)", boxShadow: "-4px 4px 0 var(--curse-deep)" }}>
        <div className="t-cond" style={{ fontSize: 12, color: "var(--paper)", letterSpacing: "0.18em" }}>SCORE</div>
        <div className="t-mono" style={{ fontSize: 30, color: "var(--caption)", lineHeight: 1 }}>0124500</div>
        <div className="t-cond" style={{ fontSize: 12, color: "var(--paper)", letterSpacing: "0.18em", marginTop: 6 }}>COMBO</div>
        <div className="t-display" style={{ fontSize: 28, color: "var(--blood)", lineHeight: 1 }}>x12 !!</div>
      </div>
    </div>

    {/* Bottom-LEFT: currently equipped weapon ONLY (no inventory) */}
    <div style={{ position: "absolute", bottom: 18, left: 18, zIndex: 20, display: "flex", gap: 10, alignItems: "center" }}>
      <div className="tile" style={{ width: 72, height: 72, background: "var(--paper)", display: "flex", alignItems: "center", justifyContent: "center", flexDirection: "column", padding: 0 }}>
        <div style={{ width: 44, height: 7, background: "linear-gradient(90deg, #6b4423, #8a5a30)", border: "2px solid var(--ink)", transform: "rotate(-25deg)" }} />
        <div className="t-cond" style={{ fontSize: 11, marginTop: 6, letterSpacing: "0.08em" }}>BAT</div>
      </div>
      <div>
        <div className="t-mono" style={{ fontSize: 11, color: "var(--paper)", letterSpacing: "0.15em" }}>IN HAND · 88/100</div>
        <div style={{ width: 130, height: 7, background: "var(--ink)", border: "2px solid var(--paper)", marginTop: 4 }}>
          <div style={{ height: "100%", width: "88%", background: "var(--green)" }} />
        </div>
        <div className="t-mono" style={{ fontSize: 10, color: "var(--paper)", opacity: 0.7, marginTop: 4, letterSpacing: "0.1em" }}>
          PICK UP NEXT WEAPON ON THE PATH ▶
        </div>
      </div>
    </div>

    {/* Bottom-right: controls hint */}
    <div style={{ position: "absolute", bottom: 18, right: 18, zIndex: 20, display: "flex", gap: 6, fontFamily: "Special Elite, monospace", fontSize: 11, color: "var(--paper)", letterSpacing: "0.1em", alignItems: "center" }}>
      <span className="chip" style={{ background: "var(--paper)", color: "var(--ink)" }}>← →</span><span>MOVE</span>
      <span className="chip" style={{ background: "var(--paper)", color: "var(--ink)" }}>↑</span><span>JUMP</span>
      <span className="chip" style={{ background: "var(--paper)", color: "var(--ink)" }}>↓</span><span>DROP</span>
      <span className="chip" style={{ background: "var(--blood)", color: "var(--paper)" }}>X</span><span>SWING</span>
      <span className="chip" style={{ background: "var(--curse)", color: "var(--paper)" }}>Y</span><span>HYPE</span>
    </div>

    {/* Annotation labels */}
    <div style={{ position: "absolute", top: "38%", left: "32%", zIndex: 30, transform: "rotate(-3deg)" }}>
      <div className="bubble" style={{ fontSize: 12, maxWidth: 160, padding: "5px 9px" }}>
        MULTI-TIER PATH — JUMP UP, DROP DOWN, AVOID THE PIT
      </div>
    </div>
    <div style={{ position: "absolute", top: "62%", right: "10%", zIndex: 30, transform: "rotate(4deg)" }}>
      <div className="bubble" style={{ fontSize: 12, maxWidth: 140, padding: "5px 9px" }}>
        ENEMY FACES = REAL PLAYER PHOTOS (DROP-IN)
      </div>
    </div>
    <div style={{ position: "absolute", bottom: "20%", left: "76%", zIndex: 30, transform: "rotate(-4deg)" }}>
      <div className="bubble" style={{ fontSize: 12, maxWidth: 130, padding: "5px 9px" }}>
        PIT TRAP — DEATH OR JUMP
      </div>
    </div>
  </div>
);

window.GameplayHUD = GameplayHUD;
