/* Title screen + main menu */

const TitleScreen = () => (
  <div style={{ width: "100%", height: "100%", position: "relative", overflow: "hidden", background: "var(--ink)" }} className="scanlines">
    {/* Castle background */}
    <div style={{ position: "absolute", inset: 0, backgroundImage: "url('assets/castle-bg.png')", backgroundSize: "cover", backgroundPosition: "center" }} />
    <div style={{ position: "absolute", inset: 0, background: "linear-gradient(180deg, rgba(10,10,18,0.4) 0%, rgba(10,10,18,0.85) 100%)" }} />
    <div className="halftone" style={{ position: "absolute", inset: 0, opacity: 0.2 }} />

    {/* Caption top-left */}
    <div className="caption" style={{ position: "absolute", top: 24, left: 24, maxWidth: 260, zIndex: 5 }}>
      A STREAMER. A KIDNAPPING.<br/>
      A VERY ANGRY BAT.
    </div>

    {/* Logo */}
    <div style={{ position: "absolute", top: "18%", left: "50%", transform: "translateX(-50%)", textAlign: "center", zIndex: 10 }}>
      <div className="t-display" style={{ fontSize: 110, lineHeight: 0.85, color: "var(--caption)", WebkitTextStroke: "5px var(--ink)", textShadow: "8px 8px 0 var(--ink), 8px 8px 0 var(--curse-deep)", letterSpacing: "0.03em" }}>
        BAKHIRA
      </div>
      <div className="t-shout" style={{ fontSize: 26, color: "var(--paper)", marginTop: 4, letterSpacing: "0.25em", textShadow: "3px 3px 0 var(--curse-deep)" }}>
        THE CURSED STREAM
      </div>
    </div>

    {/* Hero on right */}
    <img src="assets/hero.png" style={{ position: "absolute", bottom: -10, right: "8%", height: "75%", filter: "drop-shadow(10px 0 0 var(--ink)) drop-shadow(-6px 0 0 var(--ink))", zIndex: 4 }} />

    {/* SFX behind hero */}
    <div style={{ position: "absolute", bottom: "30%", right: "32%", zIndex: 3 }}>
      <span className="sfx" style={{ fontSize: 72, color: "var(--blood)" }}>SWING!</span>
    </div>

    {/* Menu */}
    <div style={{ position: "absolute", bottom: 50, left: "8%", display: "flex", flexDirection: "column", gap: 14, zIndex: 10 }}>
      <div className="btn-comic primary" style={{ fontSize: 28, padding: "14px 28px", minWidth: 280 }}>
        <span style={{ color: "var(--caption)", marginRight: 12 }}>▶</span> START NEW STREAM
      </div>
      <div className="btn-comic" style={{ fontSize: 22, padding: "10px 22px", minWidth: 240 }}>
        CONTINUE
      </div>
      <div className="btn-comic" style={{ fontSize: 22, padding: "10px 22px", minWidth: 240 }}>
        STAGE SELECT
      </div>
      <div className="btn-comic" style={{ fontSize: 22, padding: "10px 22px", minWidth: 240 }}>
        SETTINGS
      </div>
    </div>

    {/* Press start prompt */}
    <div className="t-mono" style={{ position: "absolute", bottom: 18, right: 24, color: "var(--caption)", fontSize: 22, zIndex: 10, animation: "blink 1.2s infinite" }}>
      ▼ PRESS [ENTER] TO BEGIN
    </div>

    {/* Footer chip */}
    <div style={{ position: "absolute", top: 24, right: 24, zIndex: 10 }} className="chip">
      v0.1 · DEMO BUILD
    </div>
  </div>
);

const StageSelect = () => {
  const stages = [
    { num: "01", name: "THE STREAM ROOM", sub: "TUTORIAL · COZY GONE WRONG", boss: "MOD_JENNY", locked: false, done: true },
    { num: "02", name: "DARKWEB ALLEY",   sub: "BACKSTREET TROLLS",        boss: "SIR_PINGS", locked: false, done: true },
    { num: "03", name: "COASTAL CLIFFS",  sub: "APPROACH TO THE CASTLE",   boss: "THE KRAKEN_88", locked: false, done: false, current: true },
    { num: "04", name: "CASTLE GATES",    sub: "GUARDS OF THE GATEKEEP",   boss: "WARDEN_VIRGIL", locked: true },
    { num: "05", name: "DUNGEON HALLS",   sub: "TORCHES & TICKETS",        boss: "RNG_GHOUL", locked: true },
    { num: "06", name: "THRONE ROOM",     sub: "FINAL CONFRONTATION",      boss: "THE DREADMOD", locked: true, isFinal: true },
  ];
  return (
    <div style={{ width: "100%", height: "100%", position: "relative", overflow: "hidden", background: "var(--night)" }}>
      <div style={{ position: "absolute", inset: 0, backgroundImage: "url('assets/castle-bg.png')", backgroundSize: "cover", backgroundPosition: "center", filter: "saturate(0.6) brightness(0.5)" }} />
      <div style={{ position: "absolute", inset: 0, background: "linear-gradient(180deg, rgba(10,10,18,0.6), rgba(10,10,18,0.9))" }} />
      <div className="halftone" style={{ position: "absolute", inset: 0, opacity: 0.15 }} />

      {/* Header */}
      <div style={{ position: "relative", padding: "26px 32px", display: "flex", justifyContent: "space-between", alignItems: "flex-end", zIndex: 5 }}>
        <div>
          <div className="chip">SELECT YOUR STAGE</div>
          <div className="t-display" style={{ fontSize: 56, color: "var(--paper)", lineHeight: 0.9, marginTop: 6, textShadow: "4px 4px 0 var(--ink)" }}>
            THE ROAD TO HER
          </div>
        </div>
        <div style={{ display: "flex", gap: 14, alignItems: "center" }}>
          <div className="caption">PROGRESS · 2 / 6 CLEARED</div>
          <div style={{ display: "flex", gap: 4 }}>
            <span className="heart" /><span className="heart" /><span className="heart" /><span className="heart empty" /><span className="heart empty" />
          </div>
        </div>
      </div>

      {/* Stage grid */}
      <div style={{ position: "absolute", inset: "140px 32px 32px 32px", display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gridTemplateRows: "1fr 1fr", gap: 18, zIndex: 5 }}>
        {stages.map((s) => (
          <div key={s.num} className="tile" style={{ padding: 0, position: "relative", overflow: "hidden", opacity: s.locked ? 0.55 : 1, background: s.isFinal ? "var(--curse-deep)" : (s.current ? "var(--caption)" : "var(--paper)") }}>
            {/* art area */}
            <div style={{ height: "60%", background: s.isFinal
                ? "radial-gradient(circle at 50% 60%, var(--curse), var(--ink))"
                : s.locked ? "linear-gradient(180deg, #2a2a35, #14141f)"
                : "linear-gradient(180deg, var(--night-3), var(--night))", position: "relative", borderBottom: "3px solid var(--ink)" }}>
              <div className="halftone" style={{ position: "absolute", inset: 0, opacity: 0.25 }} />
              {/* stage number */}
              <div className="t-display" style={{ position: "absolute", top: 8, right: 12, fontSize: 56, color: "rgba(255,255,255,0.15)", lineHeight: 1 }}>{s.num}</div>
              {/* locked icon */}
              {s.locked && (
                <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center", color: "var(--paper)" }}>
                  <div className="t-display" style={{ fontSize: 48, opacity: 0.6 }}>🔒 LOCKED</div>
                </div>
              )}
              {/* mini "screenshot" */}
              {!s.locked && (
                <div style={{ position: "absolute", inset: "20% 20% 10% 14%", display: "flex", alignItems: "flex-end", gap: 8 }}>
                  <div style={{ width: 28, height: 44, background: "var(--paper)", border: "2px solid var(--ink)" }} />
                  <div style={{ width: 22, height: 30, background: "var(--blood)", border: "2px solid var(--ink)" }} />
                  <div style={{ width: 22, height: 30, background: "var(--blood)", border: "2px solid var(--ink)" }} />
                  <div style={{ flex: 1 }} />
                  {s.isFinal && <div style={{ width: 48, height: 60, background: "var(--curse)", border: "3px solid var(--ink)" }} />}
                </div>
              )}
              {/* current marker */}
              {s.current && (
                <div className="sfx" style={{ position: "absolute", top: 10, left: 12, fontSize: 24 }}>YOU!</div>
              )}
              {s.done && (
                <div className="chip" style={{ position: "absolute", top: 12, left: 12, background: "var(--green)", color: "var(--ink)" }}>CLEARED ✓</div>
              )}
            </div>
            {/* info */}
            <div style={{ padding: "10px 14px", color: s.isFinal ? "var(--paper)" : "var(--ink)" }}>
              <div className="t-display" style={{ fontSize: 24, lineHeight: 1 }}>{s.name}</div>
              <div className="t-mono" style={{ fontSize: 14, opacity: 0.8, marginTop: 2 }}>
                {s.sub}
              </div>
              <div style={{ marginTop: 6, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                <span style={{ fontSize: 11, fontFamily: "Special Elite, monospace", letterSpacing: "0.1em" }}>
                  BOSS · {s.boss}
                </span>
                {!s.locked && <span className="chip" style={{ background: s.isFinal ? "var(--caption)" : "var(--blood)", color: s.isFinal ? "var(--ink)" : "var(--paper)" }}>{s.current ? "ENTER ▶" : (s.done ? "REPLAY" : "PLAY")}</span>}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

window.TitleScreen = TitleScreen;
window.StageSelect = StageSelect;
