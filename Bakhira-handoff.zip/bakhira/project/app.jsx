/* App — design canvas of all game screens */

const { DesignCanvas, DCSection, DCArtboard } = window;

const App = () => (
  <DesignCanvas
    title="BAKHIRA · THE CURSED STREAM"
    subtitle="Game design pitch · v0.1 · pulp-comic side-scrolling brawler"
    backgroundColor="#1a1a22"
  >
    <DCSection id="brand" title="Brand · Hero · Story">
      <DCArtboard id="brand-sheet" label="Brand & Hero Sheet" width={1400} height={900}>
        <BrandSheet />
      </DCArtboard>
      <DCArtboard id="story-comic" label="Story Intro · Comic Panels" width={1600} height={1000}>
        <StoryComic />
      </DCArtboard>
    </DCSection>

    <DCSection id="menus" title="Menus · Stage Select">
      <DCArtboard id="title-screen" label="Title Screen" width={1280} height={720}>
        <TitleScreen />
      </DCArtboard>
      <DCArtboard id="stage-select" label="Stage Select" width={1280} height={720}>
        <StageSelect />
      </DCArtboard>
    </DCSection>

    <DCSection id="gameplay" title="Gameplay · HUD · Systems">
      <DCArtboard id="gameplay-hud" label="In-Game HUD (Stage 03)" width={1280} height={720}>
        <GameplayHUD />
      </DCArtboard>
      <DCArtboard id="weapons" label="Weapons & Pickups Catalog" width={1400} height={900}>
        <WeaponsCatalog />
      </DCArtboard>
    </DCSection>

    <DCSection id="combat" title="Boss · Endings">
      <DCArtboard id="boss-fight" label="Final Boss · The Dreadmod" width={1280} height={720}>
        <BossFight />
      </DCArtboard>
      <DCArtboard id="endings" label="Game Over · Stage Clear" width={1600} height={720}>
        <Endings />
      </DCArtboard>
    </DCSection>
  </DesignCanvas>
);

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(<App />);
