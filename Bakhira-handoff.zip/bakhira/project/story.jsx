/* Story intro — comic panel layout */

const StoryComic = () => (
  <div style={{ width: "100%", height: "100%", background: "var(--paper-2)", padding: "28px", position: "relative", overflow: "hidden" }} className="halftone-light">
    {/* Header */}
    <div style={{ display: "flex", alignItems: "flex-end", justifyContent: "space-between", marginBottom: 18 }}>
      <div>
        <div className="chip" style={{ marginBottom: 8 }}>02 · STORY INTRO</div>
        <div className="t-display" style={{ fontSize: 44, lineHeight: 0.9 }}>
          ISSUE #1 · <span style={{ color: "var(--curse)" }}>THE CURSE</span>
        </div>
      </div>
      <div className="t-type" style={{ fontSize: 12, opacity: 0.7, maxWidth: 340, textAlign: "right" }}>
        Plays as full-screen comic panels on game start. Each panel fades in
        with a typewriter caption; player taps SPACE to advance.
      </div>
    </div>

    {/* Panel grid — comic gutter layout */}
    <div style={{ display: "grid", gridTemplateColumns: "1.2fr 1fr 1fr", gridTemplateRows: "1fr 1fr", gap: 18, height: "calc(100% - 90px)" }}>

      {/* Panel 1 — streaming with GF (big) */}
      <div className="panel-dark" style={{ gridRow: "1 / span 2", position: "relative" }}>
        <div style={{ position: "absolute", inset: 0, background: "linear-gradient(180deg, #2a1f3a 0%, #1a1226 100%)" }} />
        {/* monitor glow */}
        <div style={{ position: "absolute", left: "50%", top: "55%", transform: "translate(-50%, -50%)", width: 360, height: 220, background: "radial-gradient(ellipse, rgba(95,182,200,0.4) 0%, transparent 70%)" }} />
        {/* desk silhouette */}
        <div style={{ position: "absolute", bottom: 0, left: 0, right: 0, height: "45%", background: "linear-gradient(180deg, transparent, var(--ink))" }} />
        {/* monitor */}
        <div style={{ position: "absolute", left: "50%", top: "42%", transform: "translate(-50%, -50%)", width: 240, height: 150, background: "var(--ink)", border: "4px solid var(--paper)", boxShadow: "0 0 0 4px var(--ink)" }}>
          <div style={{ width: "100%", height: "100%", background: "linear-gradient(135deg, #5fb6c8, #2a6f80)", display: "flex", alignItems: "center", justifyContent: "center", color: "var(--ink)" }} className="t-shout">
            <span style={{ fontSize: 22 }}>LIVE • 18K</span>
          </div>
        </div>
        {/* hero silhouette */}
        <img src="assets/hero.png" style={{ position: "absolute", bottom: 0, left: "12%", height: "70%", filter: "brightness(0.35) drop-shadow(0 0 30px rgba(95,182,200,0.5))" }} />
        {/* GF silhouette (placeholder) */}
        <div style={{ position: "absolute", bottom: "5%", right: "10%", width: 140, height: "55%", background: "linear-gradient(180deg, #3a2840, #1a1226)", clipPath: "polygon(40% 0, 60% 0, 75% 25%, 80% 100%, 20% 100%, 25% 25%)", border: "2px solid rgba(255,255,255,0.15)" }} />
        <div style={{ position: "absolute", bottom: "8%", right: "11%", width: 60, height: 60, borderRadius: "50%", background: "linear-gradient(135deg, #f5db7a, #c44a8c)", opacity: 0.6 }} />

        {/* caption top */}
        <div className="caption" style={{ position: "absolute", top: 18, left: 18, maxWidth: 260 }}>
          TUESDAY NIGHT. THE STREAM IS POPPING.<br/>
          18 THOUSAND VIEWERS. HIS GIRL IS LAUGHING.
        </div>
        {/* bubble */}
        <div className="bubble" style={{ position: "absolute", bottom: 28, left: 28, maxWidth: 220, fontSize: 15 }}>
          "BABE — DROP A SUB IN CHAT, IT'S BEEN A GOOD ONE."
        </div>
        {/* panel num */}
        <div style={{ position: "absolute", bottom: 12, right: 14, color: "var(--paper)", fontFamily: "Bangers, sans-serif", fontSize: 28, opacity: 0.4 }}>01</div>
      </div>

      {/* Panel 2 — chat goes weird */}
      <div className="panel-dark" style={{ position: "relative", background: "var(--ink)" }}>
        <div className="halftone" style={{ position: "absolute", inset: 0, opacity: 0.4 }} />
        {/* chat list */}
        <div style={{ position: "absolute", inset: "30px 20px 50px 20px", display: "flex", flexDirection: "column", gap: 6, fontFamily: "VT323, monospace", fontSize: 16, color: "var(--paper)" }}>
          <div><span style={{ color: "#5fb6c8" }}>xX_p1xel:</span> lmaoo classic</div>
          <div><span style={{ color: "#e8b04a" }}>g4mer42:</span> W stream</div>
          <div><span style={{ color: "#5fa05a" }}>m0d_jenny:</span> hi babe :3</div>
          <div style={{ color: "var(--curse)", textShadow: "0 0 8px var(--curse)" }}>
            ▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓
          </div>
          <div style={{ color: "var(--curse)", textShadow: "0 0 8px var(--curse)" }}>
            DREAD_M0D: i see you, streamer.
          </div>
          <div style={{ color: "var(--curse)", textShadow: "0 0 8px var(--curse)" }}>
            DREAD_M0D: i'm coming through.
          </div>
        </div>
        <div className="caption" style={{ position: "absolute", top: 14, left: 14 }}>
          THEN CHAT WENT QUIET...
        </div>
        <div style={{ position: "absolute", bottom: 12, right: 14, color: "var(--paper)", fontFamily: "Bangers, sans-serif", fontSize: 28, opacity: 0.4 }}>02</div>
      </div>

      {/* Panel 3 — villain appears */}
      <div className="panel-dark" style={{ position: "relative", overflow: "hidden" }}>
        <div style={{ position: "absolute", inset: 0, background: "radial-gradient(circle at 60% 40%, var(--curse) 0%, var(--curse-deep) 30%, var(--ink) 70%)" }} />
        <div className="halftone" style={{ position: "absolute", inset: 0, opacity: 0.5 }} />
        {/* villain silhouette - hooded figure */}
        <div style={{ position: "absolute", bottom: 0, left: "50%", transform: "translateX(-50%)", width: 180, height: "90%", background: "var(--ink)", clipPath: "polygon(35% 0, 65% 0, 80% 15%, 90% 100%, 10% 100%, 20% 15%)" }} />
        {/* glowing eyes */}
        <div style={{ position: "absolute", top: "32%", left: "44%", width: 12, height: 4, background: "var(--caption)", boxShadow: "0 0 12px var(--caption)" }} />
        <div style={{ position: "absolute", top: "32%", right: "44%", width: 12, height: 4, background: "var(--caption)", boxShadow: "0 0 12px var(--caption)" }} />
        {/* SFX */}
        <div style={{ position: "absolute", top: 30, right: 14, transform: "rotate(8deg)" }}>
          <div className="sfx" style={{ fontSize: 44 }}>CLACK!</div>
        </div>
        <div className="caption" style={{ position: "absolute", bottom: 14, left: 14, right: 14 }}>
          A HOODED FIGURE STEPPED OUT OF THE MONITOR.
        </div>
        <div style={{ position: "absolute", bottom: 12, right: 14, color: "var(--paper)", fontFamily: "Bangers, sans-serif", fontSize: 28, opacity: 0.5 }}>03</div>
      </div>

      {/* Panel 4 — kidnap */}
      <div className="panel-dark" style={{ position: "relative", overflow: "hidden" }}>
        <div style={{ position: "absolute", inset: 0, background: "linear-gradient(135deg, #2a1226, #1a0a16)" }} />
        {/* motion lines */}
        <div style={{ position: "absolute", inset: 0, background: "repeating-linear-gradient(75deg, transparent 0 8px, rgba(255,255,255,0.06) 8px 10px)" }} />
        {/* purple swoosh */}
        <div style={{ position: "absolute", top: "20%", left: "10%", right: "10%", height: 4, background: "var(--curse)", transform: "rotate(-12deg)", boxShadow: "0 0 20px var(--curse)" }} />
        {/* GF being carried */}
        <div style={{ position: "absolute", top: "30%", right: 24, fontFamily: "Bangers, sans-serif", fontSize: 26, color: "var(--paper)", transform: "rotate(-8deg)" }}>
          "BABE—!!"
        </div>
        <div className="caption" style={{ position: "absolute", bottom: 14, left: 14, right: 14 }}>
          HE TOOK HER. JUST LIKE THAT.
        </div>
        <div style={{ position: "absolute", bottom: 12, right: 14, color: "var(--paper)", fontFamily: "Bangers, sans-serif", fontSize: 28, opacity: 0.4 }}>04</div>
      </div>

      {/* Panel 5 — curse */}
      <div className="panel-dark" style={{ position: "relative", overflow: "hidden", gridColumn: "2 / span 1" }}>
        <div style={{ position: "absolute", inset: 0, background: "radial-gradient(circle at 30% 60%, var(--curse-deep), var(--ink) 80%)" }} />
        <div className="halftone" style={{ position: "absolute", inset: 0, opacity: 0.4 }} />
        {/* curse circle */}
        <div style={{ position: "absolute", left: "50%", top: "55%", transform: "translate(-50%, -50%)", width: 180, height: 180, border: "3px solid var(--curse)", borderRadius: "50%", boxShadow: "0 0 40px var(--curse), inset 0 0 20px var(--curse)" }} />
        <div style={{ position: "absolute", left: "50%", top: "55%", transform: "translate(-50%, -50%) rotate(15deg)", width: 140, height: 140, border: "2px dashed var(--caption)", borderRadius: "50%" }} />
        <div className="caption" style={{ position: "absolute", top: 14, left: 14, right: 14, background: "var(--curse)", color: "var(--paper)" }}>
          "ENJOY THE CURSE, STREAMER."
        </div>
        <div style={{ position: "absolute", bottom: 12, right: 14, color: "var(--paper)", fontFamily: "Bangers, sans-serif", fontSize: 28, opacity: 0.5 }}>05</div>
      </div>

      {/* Panel 6 — vow */}
      <div className="panel-dark" style={{ position: "relative", overflow: "hidden" }}>
        <div style={{ position: "absolute", inset: 0, backgroundImage: "url('assets/castle-bg.png')", backgroundSize: "cover", backgroundPosition: "right center" }} />
        <div style={{ position: "absolute", inset: 0, background: "linear-gradient(90deg, rgba(10,10,18,0.8) 0%, transparent 60%)" }} />
        <img src="assets/hero.png" style={{ position: "absolute", bottom: 0, left: "-5%", height: "98%", filter: "drop-shadow(8px 0 0 var(--ink))" }} />
        <div className="bubble" style={{ position: "absolute", top: 18, right: 18, maxWidth: 200, fontSize: 16 }}>
          "I'M COMING FOR HER. EVERY ONE OF YOU. STAGE BY STAGE."
        </div>
        <div className="caption" style={{ position: "absolute", bottom: 14, left: 14 }}>
          SOMEWHERE BY THE COAST... A CASTLE.<br/>HE GRABBED THE BAT.
        </div>
        <div style={{ position: "absolute", bottom: 12, right: 14, color: "var(--paper)", fontFamily: "Bangers, sans-serif", fontSize: 28, opacity: 0.5 }}>06</div>
      </div>
    </div>
  </div>
);

window.StoryComic = StoryComic;
